// DOM Elements
const todoInput = document.getElementById("todo-input");
const addButton = document.getElementById("add-button");
const todoList = document.getElementById("todo-list");

// Retrieve saved tasks from localStorage and display them
document.addEventListener("DOMContentLoaded", loadTasks);

// Event listener to add a task
addButton.addEventListener("click", addTask);

// Function to add a task
function addTask() {
    const taskText = todoInput.value.trim();

    // Validation for empty input
    if (taskText === "") {
        alert("Please enter a task!");
        return;
    }

    // Create task item
    const taskItem = createTaskElement(taskText);

    // Append task to the list
    todoList.appendChild(taskItem);

    // Save to localStorage
    saveTask(taskText);

    // Clear input field
    todoInput.value = "";
}

// Function to create a task element
function createTaskElement(taskText) {
    const li = document.createElement("li");

    // Task text
    const taskSpan = document.createElement("span");
    taskSpan.textContent = taskText;
    li.appendChild(taskSpan);

    // Delete button
    const deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";
    deleteButton.addEventListener("click", () => {
        li.remove(); // Remove from DOM
        removeTask(taskText); // Remove from localStorage
    });
    li.appendChild(deleteButton);

    return li;
}

// Function to save a task to localStorage
function saveTask(taskText) {
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.push(taskText);
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Function to load tasks from localStorage
function loadTasks() {
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.forEach((task) => {
        const taskItem = createTaskElement(task);
        todoList.appendChild(taskItem);
    });
}

// Function to remove a task from localStorage
function removeTask(taskText) {
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks = tasks.filter((task) => task !== taskText);
    localStorage.setItem("tasks", JSON.stringify(tasks));
}
