// Function to validate the contact form
document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");

    form.addEventListener("submit", (event) => {
        event.preventDefault(); // Prevent the form from submitting immediately

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const message = document.getElementById("message").value.trim();

        // Validate name
        if (name === "") {
            alert("Please enter your name.");
            return;
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert("Please enter a valid email address.");
            return;
        }

        // Validate message
        if (message === "") {
            alert("Please enter your message.");
            return;
        }

        // If all validations pass
        alert("Thank you for reaching out! Your message has been sent.");
        form.reset(); // Clear the form after submission
    });
});
