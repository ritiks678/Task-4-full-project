// Array of products
const products = [
  { id: 1, name: "Smartphone", category: "electronics", price: 300, rating: 4.5, image: "images/smartphone.jpg" },
  { id: 2, name: "Jeans", category: "clothing", price: 50, rating: 4.0, image: "images/jeans.jpg" },
  { id: 3, name: "Laptop", category: "electronics", price: 800, rating: 4.7, image: "images/laptop.jpg" },
  { id: 4, name: "T-Shirt", category: "clothing", price: 20, rating: 4.2, image: "images/tshirts.jpg" },
  { id: 5, name: "Fiction Book", category: "books", price: 15, rating: 4.8, image: "images/fictionbook.jpg" },
  { id: 6, name: "Cookbook", category: "books", price: 25, rating: 4.3, image: "images/cookbook.jpg" },
];

// Select DOM elements
const productList = document.getElementById("product-list");
const categoryFilter = document.getElementById("category-filter");
const sortOption = document.getElementById("sort-option");

// Function to display products
function displayProducts(filteredProducts) {
  productList.innerHTML = ""; // Clear previous products

  filteredProducts.forEach(product => {
      const productCard = document.createElement("div");
      productCard.className = "product-card";

      productCard.innerHTML = `
          <img src="${product.image}" alt="${product.name}">
          <h3>${product.name}</h3>
          <p class="price">$${product.price}</p>
          <p class="rating">⭐ ${product.rating}</p>
      `;

      productList.appendChild(productCard);
  });
}

// Function to filter and sort products
function updateProducts() {
  let filteredProducts = products;

  // Filter by category
  const selectedCategory = categoryFilter.value;
  if (selectedCategory !== "all") {
      filteredProducts = filteredProducts.filter(product => product.category === selectedCategory);
  }

  // Sort by selected option
  const selectedSort = sortOption.value;
  if (selectedSort === "price-asc") {
      filteredProducts.sort((a, b) => a.price - b.price);
  } else if (selectedSort === "price-desc") {
      filteredProducts.sort((a, b) => b.price - a.price);
  } else if (selectedSort === "rating") {
      filteredProducts.sort((a, b) => b.rating - a.rating);
  }

  displayProducts(filteredProducts);
}

// Event listeners for filter and sort
categoryFilter.addEventListener("change", updateProducts);
sortOption.addEventListener("change", updateProducts);

// Initial display
displayProducts(products);
